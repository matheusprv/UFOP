var indexSectionsWithContent =
{
  0: "acefglmnorstuv~",
  1: "fms",
  2: "fmsu",
  3: "acefglmorsu~",
  4: "fnstv",
  5: "fs",
  6: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "related"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Friends"
};

