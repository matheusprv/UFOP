#ifndef UNIT_HANDLE_BODY_H
#define UNIT_HANDLE_BODY_H

#include "../../src/Model.h"
#include "../../src/SystemImpl.h"
#include "../Flows/FlowComplexo.h"
#include "../Flows/FlowExponencial.h"
#include "../Flows/FlowLogistico.h"

#include <cstdlib>
#include <iostream>
#include <cstdlib>
#include <assert.h>

using namespace std;

void run_unit_test_handle_body();

#endif