var class_system_handle =
[
    [ "SystemHandle", "class_system_handle.html#a6904884c79e376b7df6c2b6862a73453", null ],
    [ "SystemHandle", "class_system_handle.html#ae44d95110f4b5a081fa88c47c62cb0ce", null ],
    [ "SystemHandle", "class_system_handle.html#a4692fdcb5059337878b2edaa43ce2f91", null ],
    [ "SystemHandle", "class_system_handle.html#a89a4db1dc76231a95167a904fd0175c4", null ],
    [ "SystemHandle", "class_system_handle.html#a1e951c1b9cb9cb985f36d7d4b7220714", null ],
    [ "~SystemHandle", "class_system_handle.html#a4b917da05a077c741b5ddddadf2f5d95", null ],
    [ "getName", "class_system_handle.html#ae0e8c19df92e41d60f2156562fd2bd52", null ],
    [ "getValue", "class_system_handle.html#aeb69190853dc47d4c73ccd3928bfc3a1", null ],
    [ "setName", "class_system_handle.html#a6b61e31a32c25ac9e3b92bc36e1622ee", null ],
    [ "setValue", "class_system_handle.html#a820ce5b07d9afc47a850ce7bf44a1cc1", null ]
];