var funcional__tests_8cpp =
[
    [ "DEBUGING", "funcional__tests_8cpp.html#aeff79046387df0de04e7de11061a704b", null ],
    [ "complexFuncionalTest", "funcional__tests_8cpp.html#a943dfe0c597a01c9760c140715fed527", null ],
    [ "exponentialFuncionalTest", "funcional__tests_8cpp.html#a2c448ffaffdff4b03c825a01dffa6f27", null ],
    [ "floatingPointComparison", "funcional__tests_8cpp.html#adbcc4e1dba9b8de80d1b4ba44805a9dc", null ],
    [ "logisticalFuncionalTest", "funcional__tests_8cpp.html#a60914db64bde71b56d69320797266c29", null ],
    [ "numBodyCreated", "funcional__tests_8cpp.html#ac1322042429ed9724fbef55908244f3b", null ],
    [ "numBodyDeleted", "funcional__tests_8cpp.html#aba38ebae7f83ef57afab8c447dddb6cf", null ],
    [ "numHandleCreated", "funcional__tests_8cpp.html#aac78cb29dfe4a565da68073b0beebf2f", null ],
    [ "numHandleDeleted", "funcional__tests_8cpp.html#a01128a06118f949a0b24a3d080f515fd", null ]
];