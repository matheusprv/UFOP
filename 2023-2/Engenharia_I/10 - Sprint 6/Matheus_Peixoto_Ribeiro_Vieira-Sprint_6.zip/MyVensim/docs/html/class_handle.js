var class_handle =
[
    [ "Handle", "class_handle.html#a6a72028918adf79c0ff8d9996e5e4107", null ],
    [ "~Handle", "class_handle.html#addd59fdf43baa517a06d44e1125b5ab1", null ],
    [ "Handle", "class_handle.html#af304e7014a2e600e235140d246783f85", null ],
    [ "operator=", "class_handle.html#a52e146e2a1427c8e7d3a692e9378185a", null ],
    [ "pImpl_", "class_handle.html#a16021e57596d7369dfa1a9fadc35c06f", null ]
];