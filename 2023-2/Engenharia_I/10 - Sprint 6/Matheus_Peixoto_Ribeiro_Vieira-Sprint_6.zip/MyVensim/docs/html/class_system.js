var class_system =
[
    [ "~System", "class_system.html#a2fc0f34023977cab9b628aa9f734d88c", null ],
    [ "getName", "class_system.html#ab4f23c21832d6bbef462a5a20b296912", null ],
    [ "getValue", "class_system.html#a41b673faa6c199eb8e4f204639fab4f2", null ],
    [ "setName", "class_system.html#afc362e8275b428a94c214826c60a01bc", null ],
    [ "setValue", "class_system.html#afc591b66c17ddcd2d0a5421f66750d2c", null ],
    [ "operator<<", "class_system.html#a693dc8ceac42165b1c3a6da82ce95204", null ]
];