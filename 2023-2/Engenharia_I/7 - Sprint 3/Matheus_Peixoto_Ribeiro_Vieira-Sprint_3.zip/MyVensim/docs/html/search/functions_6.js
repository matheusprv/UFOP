var searchData=
[
  ['main_0',['main',['../test_2funcional_2main_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main.cpp']]],
  ['model_1',['model',['../class_model.html#ae3b375de5f6df4faf74a95d64748e048',1,'Model::Model()'],['../class_model.html#a74e7f5c115a89cf71501e7368562bc58',1,'Model::Model(const string &amp;name)']]]
];
