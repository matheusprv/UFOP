var searchData=
[
  ['add_0',['add',['../class_model.html#a1acc6a20b2e07eb467bcb253f9b82a83',1,'Model::add(Flow *flow)'],['../class_model.html#af498f4165f6a2c79d7b131788a323571',1,'Model::add(System *system)']]]
];
