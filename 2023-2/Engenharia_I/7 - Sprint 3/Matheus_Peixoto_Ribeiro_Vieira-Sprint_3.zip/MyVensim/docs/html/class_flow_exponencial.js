var class_flow_exponencial =
[
    [ "FlowExponencial", "class_flow_exponencial.html#ae21b68d9134907774dd95a510181b947", null ],
    [ "executeEquation", "class_flow_exponencial.html#adfdac5414979085800fb4496207344d7", null ]
];