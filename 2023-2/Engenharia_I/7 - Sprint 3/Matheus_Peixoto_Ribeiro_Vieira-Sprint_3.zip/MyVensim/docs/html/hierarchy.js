var hierarchy =
[
    [ "Flow", "class_flow.html", [
      [ "FlowComplexo", "class_flow_complexo.html", null ],
      [ "FlowExponencial", "class_flow_exponencial.html", null ],
      [ "FlowLogistico", "class_flow_logistico.html", null ]
    ] ],
    [ "Model", "class_model.html", null ],
    [ "System", "class_system.html", null ]
];