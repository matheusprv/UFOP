#include <string.h>
#include <stdio.h>
#include <stdlib.h>

void quicksort(char * , int , int);

void ordenaPalavra(char *);

int verificaOrdemAlfabetica(char *, char *);

void caixaBaixa(char*);