#include <stdio.h>
#include <stdlib.h>


void merge(int *, int , int , int );

void mergeSort(int *, int , int );

int pesquisaBinaria(int *vetor, int esq, int dir, int pesquisa);