#ifndef f91_h
#define f91_h

int f91(int n);

#endif