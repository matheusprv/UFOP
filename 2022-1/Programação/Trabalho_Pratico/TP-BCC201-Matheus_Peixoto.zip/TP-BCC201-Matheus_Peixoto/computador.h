//Matheus Peixoto Ribeiro Vieira - 22.1.4104

#ifndef COMPUTADOR_H
#define COMPUTADOR_H

#include "structs.h"

int procurarVitoria(int *,int *, char **, char);

int melhorPosicao(int *, int*, char **);

void jogadaComputador(Partida *partida);

#endif